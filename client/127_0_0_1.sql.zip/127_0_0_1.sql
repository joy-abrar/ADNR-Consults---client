-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 11 Avril 2022 à 15:52
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `dbtuts`
--

-- --------------------------------------------------------

--
-- Structure de la table `tbl_uploads`
--

CREATE TABLE IF NOT EXISTS `tbl_uploads` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `file` varchar(100) NOT NULL,
  `type` varchar(10) NOT NULL,
  `size` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Contenu de la table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`id`, `file`, `type`, `size`) VALUES
(14, '24417-Capture.png', 'image/png', 253434),
(13, '99309-file.pdf', 'applicatio', 136713),
(11, '50573-plaquette CVPN.png', 'image/png', 629988),
(12, '17369-file (1).pdf', 'applicatio', 104572);
--
-- Base de données :  `projet1`
--

-- --------------------------------------------------------

--
-- Structure de la table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `evt_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `evt_start` datetime NOT NULL,
  `evt_end` datetime NOT NULL,
  `evt_text` text NOT NULL,
  `evt_color` varchar(7) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`evt_id`),
  KEY `evt_start` (`evt_start`),
  KEY `evt_end` (`evt_end`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Contenu de la table `events`
--

INSERT INTO `events` (`evt_id`, `evt_start`, `evt_end`, `evt_text`, `evt_color`, `userId`) VALUES
(10, '2022-04-08 15:00:00', '2022-04-08 16:00:00', 'un evenement du test', '#e92d0c', 14),
(11, '2022-04-08 16:00:00', '2022-04-08 17:00:00', 'evenement de rendez-vous', '#c65d90', 21);

-- --------------------------------------------------------

--
-- Structure de la table `flowers`
--

CREATE TABLE IF NOT EXISTS `flowers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flowerName` text NOT NULL,
  `groupe` text NOT NULL,
  `oui` int(11) NOT NULL DEFAULT '0',
  `non` int(11) NOT NULL DEFAULT '0',
  `groupeName` text NOT NULL,
  `selectedForResult` text NOT NULL,
  `flowerMessage` text NOT NULL,
  `positiveSentence` text NOT NULL,
  `serialNumber` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Contenu de la table `flowers`
--

INSERT INTO `flowers` (`id`, `flowerName`, `groupe`, `oui`, `non`, `groupeName`, `selectedForResult`, `flowerMessage`, `positiveSentence`, `serialNumber`) VALUES
(1, 'Agrimony', '5', 0, 0, 'HypersensibilitÃ© aux influences et idÃ©es d''autrui', 'no', 'On essaie de cacher les pensÃ©es dÃ©rangeantes ainsi que son inquiÃ©tude intÃ©rieure derriÃ¨re une faÃ§ade de gaietÃ© et de dÃ©contraction. On se sent opprimÃ© dÃ¨s que rÃ¨gnent la mÃ©sentente et les querelles. On voudrait faire plaisir Ã  tout le monde. Recourt Ã  lâ€™alcool, aux cigarettes, aux mÃ©dicaments, pour , de bonne humeur, surmonter les difficultÃ©s et refouler les pensÃ©es dÃ©sagrÃ©ables.\r\nSincÃ©ritÃ©, franchise, aptitude Ã  la confrontation. On a une rÃ©elle gaietÃ© de cÅ“ur. Optimiste confiant, on vit dans une paix et une harmonie vÃ©ritables.\r\n', 'Je me sens en paix. Je suis sincÃ¨re. Je me montre comme je suis.', 0),
(2, 'Aspen', '1', 0, 0, 'Peurs', 'no', 'Angoisses inexplicables et vagues, prÃ©monitions, craintes secrÃ¨tes dâ€™une catastrophe imminente, liÃ© Ã  tout ce qui est nocturne. DÃ©lire de persÃ©cution, comme lâ€™objet dâ€™un Â«Â mauvais sortÂ Â».\r\nPermet dâ€™avancer sans peur et en confiance sur son chemin, on connaÃ®t sa sensibilitÃ© particuliÃ¨re et on peut lâ€™utiliser de faÃ§on constructive. Sentiment de sÃ©curitÃ©.\r\n', 'Je suis protÃ©gÃ©, je suis dans mon centre, je suis fort', 0),
(3, 'Beech', '7', 0, 0, 'Soucis excessif du bien-Ãªtre d''autrui', 'no', 'Manie de critiquer, prÃ©jugÃ©s, intolÃ©rance. On juge les autres sans aucune tentative de comprÃ©hension ou, au contraire, on sâ€™abstient de toute critique, mÃªme constructive. On juge sÃ©vÃ¨rement les fautes des autres.  On ne dÃ©mord pas de ses prÃ©jugÃ©s.\r\nPÃ©nÃ©trante vision intellectuelle, discernement et jugements sains. La critique devient constructive et tient compte de la sensibilitÃ© des autres; on peut soi-mÃªme accepter une critique.\r\n', 'Jâ€™accepte ce qui vient. Je suis prÃ©venant. Je vois la chance dâ€™Ã©volution', 0),
(4, 'Centaury', '5', 0, 0, 'HypersensibilitÃ© aux influences et idÃ©es d''autrui', 'no', 'Faiblesse de volontÃ© propre; rÃ©action exagÃ©rÃ©e vis-Ã -vis de la volontÃ© dâ€™autres; ne peut pas dire non. On est trop mallÃ©able. On a du mal Ã  faire valoir ses dÃ©sirs ou ses droits, on cÃ¨de vite; on agit suivant lâ€™attente des autres. On ressent davantage les dÃ©sirs des autres que les siens propres. \r\nOn est conscient de ses propres dÃ©sirs et on suit son propre chemin.  On sait quand il faut dire oui, mais aussi dire non quand il faut.', 'Je maintiens ma position. Je suis tel que je suis. Je peux ce que je veux', 0),
(5, 'Cerato', '2', 0, 0, 'Incertitudes et dÃ©couragements', 'no', 'Confiance insuffisante dans sa propre intuition, on attache une valeur exagÃ©rÃ©e Ã  lâ€™opinion des autres. On nâ€™ose pas agir spontanÃ©ment. \r\nIntuitif, curieux de tout, dÃ©sireux dâ€™apprendre, on se laisse guider par sa voix intÃ©rieure, on a confiance en soi et on ne modifie pas ses dÃ©cisions.', 'Jâ€™ai confiance en moi-mÃªme, je donne suite Ã  mes premiÃ¨res impulsions', 0),
(6, 'Cherry Plum', '1', 0, 0, 'Peurs', 'no', 'Peur de perdre le contrÃ´le, de basculer dans la folie, crises de violence incontrÃ´lables. Bombe Ã  retardement. On se sent Â«Â bloquÃ©Â Â». Peur de parler de ses sentiments.\r\nApporte la sÃ©rÃ©nitÃ©, calme intÃ©rieur. On accepte ses sentiments tels quâ€™ils se prÃ©sentent. On peut plonger profondÃ©ment dans son subconscient et y  puiser les connaissances acquises pour les utiliser dans sa vie active.', 'Jâ€™ai le courage de faire face, je mâ€™ouvre Ã  mes sentiments rÃ©els', 0),
(7, 'Chestnut Bud', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'On recommence toujours les mÃªmes erreurs parce que lâ€™on nâ€™intÃ¨gre pas rÃ©ellement ses expÃ©riences et parce quâ€™elles ne servent pas de leÃ§on. On se retrouve constamment dans le mÃªme genre de difficultÃ©s, le mÃªme genre de discussions, le mÃªme genre dâ€™accidents, etc.\r\nOn est vif dâ€™esprit, on aime apprendre. Les expÃ©riences des autres servent de modÃ¨le. On tire un maximum dâ€™enseignements de ses expÃ©riences quotidiennes.', 'Je regarde la rÃ©alitÃ© en face. Jâ€™Ã©coute avec attention.Je veux apprendre', 0),
(8, 'Chicory', '7', 0, 0, 'Soucis excessif du bien-Ãªtre d''autrui', 'no', 'PossessivitÃ© sur le plan affectif; tendance Ã  sâ€™immiscer et manipuler; ne se sent pas assez valorisÃ© et aimÃ©. On veille telle une Â«Â mÃ¨re pouleÂ Â» sur les besoins, les dÃ©sirs, les affaires de sa maisonnÃ©e et de ses amis. On se rend indispensable. Amour conditionnel. Chantage par les sentiments.\r\nOn donne spontanÃ©ment, sans attente de retour. On admet que chacun a son propre projet de vie Ã  vivre. On connaÃ®t ses besoins personnels et on essaie de les rÃ©aliser soi-mÃªme.', 'Jâ€™aime donner. Je puise Ã  une source inÃ©puisable. Je sais que je suis aimÃ©', 0),
(9, 'ClÃ©matis', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'RÃªveur; se trouve, en pensÃ©es, toujours ailleurs; montre peu dâ€™intÃ©rÃªt pour ce qui se passe autour de lui. Inattentif, distrait, rÃªve les yeux ouverts; constamment Ã  la recherche dâ€™objets perdus; mauvais sens de lâ€™orientation. On dÃ©croche facilement, tendance Ã  lâ€™Ã©vanouissement.\r\nPerception du rÃ©el, plan de vie concret, on se concentre sur le faisable. Action dÃ©terminÃ©e pour exprimer la crÃ©ativitÃ© dans la rÃ©alitÃ©.', 'Je suis en Ã©veil. Jâ€™ai une claire vision. Je suis crÃ©ateur', 0),
(10, 'Crab Apple', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'On se sent intÃ©rieurement ou extÃ©rieurement souillÃ©, impur ou infectÃ©. Sens exagÃ©rÃ© de lâ€™ordre. Importance exagÃ©rÃ©e du principe de puretÃ© sur le plan psychique, spirituel ou corporel. Irritation quand une situation nâ€™est pas claire et bien rÃ©glÃ©e. Mauvaise image de soi.\r\nOn sait que lâ€™ordre nâ€™est toujours quâ€™un Ã©tat transitoire. On ne sâ€™attache pas trop aux dÃ©tails.', 'Je me sens parfaitement bien. Je mâ€™accepte comme je suis. Je distingue ce qui est important', 0),
(11, 'Elm', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'Sentiment passager de ne pas Ãªtre Ã  la hauteur de sa tÃ¢che ou de ses responsabilitÃ©s, qui prennent les dimensions dâ€™une montagne.  Sentiments dâ€™insuffisance dus Ã  lÂ â€™Ã©puisement. On ne sait plus par oÃ¹ commencer. \r\nCapable, responsable, confiant en soi. Capable de dÃ©lÃ©guer. On devient conscient de la responsabilitÃ© quâ€™on a Ã©galement vis-Ã -vis de soi-mÃªme.', 'Je fais ce que je peux. Je serai aidÃ©. Jâ€™en viendrai Ã  bout', 0),
(12, 'Gentian', '2', 0, 0, 'Incertitudes et dÃ©couragements', 'no', 'Sceptique, doute de tout, pessimiste, perd facilement courage. Sentiment dâ€™insÃ©curitÃ© par manque de foi et de confiance. On doute par principe, pour Ã©viter une future dÃ©ception.\r\nOn sait que tout problÃ¨me porte en lui sa solution. On voit dans les difficultÃ©s et les rÃ©sistances une situation dâ€™Ã©preuve qui permet dâ€™aborder lâ€™obstacle avec une foi renouvelÃ©e.', 'Jâ€™ai confiance dans lâ€™avenir, jâ€™attends lâ€™issue positive', 0),
(13, 'Gorse', '2', 0, 0, 'Incertitudes et dÃ©couragements', 'no', 'DÃ©sespoir. Sentiment que Â«Â cela ne sert plus Ã  rienÂ .Â Â» Maladies chroniques. RÃ©signation, on abdique intÃ©rieurement; mais on se laisse persuader dâ€™essayer encore une fois. On est dÃ©Ã§u par le plus petit Ã©chec. \r\nOn  reconnaÃ®t le potentiel positif dâ€™une situation difficile. On sait quâ€™il nâ€™est jamais trop tard pour faire des modifications dans sa vie. On reprÃ©sente pour les autres un potentiel dâ€™espoir.', 'Je reste debout, jâ€™espÃ¨re, je vois les nouvelles possibilitÃ©s', 0),
(14, 'Heather', '4', 0, 0, 'Solitudes', 'no', 'Egocentrique, entiÃ¨rement prÃ©occupÃ© par lui-mÃªme, besoin constant de public. Â«Â Lâ€™enfant dÃ©pendantÂ Â». On ne supporte pas la solitude, on sâ€™y sent perdu. Carences affectives dans la petite enfance.\r\nOn sait que le Guide intÃ©rieur procure tous les Ã©lÃ©ments nÃ©cessaires. On peut se consacrer totalement Ã  autrui.', 'Je me sens en toute sÃ©curitÃ©. Je reÃ§ois tout ce dont jâ€™ai besoin.Je prodigue mes soins Ã  autrui', 0),
(15, 'Holly', '5', 0, 0, 'HypersensibilitÃ© aux influences et idÃ©es d''autrui', 'no', 'ColÃ¨re, rage, haine, envie, jalousie. Insatisfait, de mauvaise humeur, irritÃ©, sans toujours savoir pourquoi. Crainte de Â«Â se faire avoirÂ Â». On se sent sentimentalement incompris. On flaire du nÃ©gatif dans presque tout. On soupÃ§onne facilement les autres. On se sent souvent vexÃ© ou blessÃ©. On ressent intÃ©rieurement un choc Ã  la vue du bonheur des autres. \r\nLe cÅ“ur donne le ton. Sentiment dâ€™union avec les autres, profonde comprÃ©hension pour le monde Ã©motionnel des Ãªtres humains. On peut se rÃ©jouir des rÃ©sultats et succÃ¨s des autres. On vit en harmonie intÃ©rieure; on est chaleureux et bienveillant.', 'Je suis plein de joie. Je suis uni en moi-mÃªme. Jâ€™aime', 0),
(16, 'Honeysuckle', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'Nostalgie du passÃ©; regrets pour des faits passÃ©s; ne vis pas dans le prÃ©sent. Mal du pays  ou dâ€™une autre personne. On glorifie le passÃ©.\r\nOn sait que la vie se vit maintenant. On a appris par les expÃ©riences du passÃ© et on en tire profit dans le prÃ©sent.', 'Je vis dans le prÃ©sent. Je regarde devant moi. Je fais le prochain pas', 0),
(17, 'Hornbeam', '2', 0, 0, 'Incertitudes et dÃ©couragements', 'no', 'Fatigue mentale; lassitude psychique passagÃ¨re ou durable. La simple pensÃ©e dâ€™une certaine tache Ã  accomplir Ã´te toute parcelle dâ€™Ã©nergie. On a besoin de stimulants (thÃ©, cafÃ©, fortifiants). Trop de tv, sociÃ©tÃ© de conso.\r\nEsprit vif, sens pour lâ€™Ã©quilibre Ã  travers des occupations compensatoires. CapacitÃ© Ã  quitter la routine et Ã  suivre une impulsion spontanÃ©e.', 'Mon esprit est frais. Jâ€™ai le tonus quâ€™il faut. Jâ€™aime mon travail', 0),
(18, 'Impatiens', '4', 0, 0, 'Solitudes', 'no', 'Impatient, facilement irritÃ©, rÃ©actions excessives. Tension mentale due Ã  un surrÃ©gime intÃ©rieur. Tout doit se faire vite et sans accrocs. Grand besoin dâ€™indÃ©pendance.\r\nBonne capacitÃ© Ã  sâ€™accorder Ã  dâ€™autres tempÃ©raments et rythmes. Patience, dÃ©licatesse, douceur.', 'Je me prends du temps. Je suis patient. Je me dÃ©tends', 0),
(19, 'Larch', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'Attente dâ€™un Ã©chec par manque de confiance en soi; complexe dâ€™infÃ©rioritÃ©. DÃ¨s le dÃ©part, on se sent infÃ©rieur aux autres. On se sous-Ã©value. PassivitÃ© et hÃ©sitation face Ã  une chance qui se prÃ©sente. On prÃ©texte une maladie pour Ã©viter de sâ€™attaquer Ã  un problÃ¨me.\r\nOn connaÃ®t, et on accepte, ses propres points forts et points faibles. On dÃ©veloppe et on utilise ses talents. On saisit une chance en lâ€™Ã©valuant concrÃ¨tement.', 'Je le peux. Je le veux. Je le fais', 0),
(20, 'Mimulus', '1', 0, 0, 'Peurs', 'no', 'Craintes; timiditÃ©; peurs spÃ©cifiques dont la cause est connue; peur du monde concret. Angoisses, phobies. HypersensibilitÃ© (froid, bruit, etc)\r\nOn est sorti de ses peurs, on connaÃ®t ses limites et on est capable de laisser approcher les choses, lâ€™esprit dÃ©tendu.. Apporte courage, humour et calme.', 'Je sens en moi le courage, je prends le risque, je vais au devant', 0),
(21, 'Mustard', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'AccÃ¨s de profonde mÃ©lancolie qui viennent et disparaissent sans raison apparente. Manque dâ€™Ã©nergie; on pleure facilement; on ne se rÃ©jouit plus de rien; on ne peut cacher son Ã©tat aux autres.\r\nOn se sent portÃ© par le fleuve de la vie. On traverse mÃªme les jours sombres avec luciditÃ© et assurance. On accepte le flux et reflux des accÃ¨s de tristesse, avec la conscience que la joie revient comme le soleil aprÃ¨s la pluie.', 'Mon cÅ“ur est lÃ©ger. Je suis rempli de joie. Je vais vers la lumiÃ¨re', 0),
(22, 'Oak', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'Au combattant abattu et Ã©puisÃ©, mais qui continu courageusement et nâ€™abandonne jamais. On sâ€™acquitte de son devoir envers et contre tout, quitte Ã  sâ€™y briser. On ne tient pas compte de ses besoins naturels de repos.\r\nOn subvient Ã  ses obligations dans le cadre de ses propres possibilitÃ©s. Grande capacitÃ© de travail, mais capacitÃ© aussi de dire: Â«Â Je mâ€™arrÃªte!Â Â»', 'Je relÃ¢che la pression. Jâ€™avance avec lÃ©gÃ¨retÃ©. Je me sens libre', 0),
(23, 'Olive', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'Epuisement total, fatigue extrÃªme du corps et de lâ€™esprit. Constat dâ€™impuissance totale.; on ne supporte plus rien; au bout du rouleau.\r\nOn sait gÃ©rer adÃ©quatement ses rÃ©serves Ã©nergÃ©tiques. On est capable dâ€™activer de grandes quantitÃ©s dâ€™Ã©nergie face Ã  une situation particuliÃ¨rement exigeante.', 'Je suis en paix. Je me sens fort. Je me repose', 0),
(24, 'Pine', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'Sentiments de culpabilitÃ© exagÃ©rÃ©s ou infondÃ©s; auto-accusation, dÃ©couragement. On sÂ â€™excuse de tout et envers tout. On se sent responsable des fautes des autres. Si lâ€™on est en meilleure position quâ€™un autre, on se le reproche. Besoin presque masochiste de sacrifice.\r\nOn sait que chaque Ãªtre humain a droit Ã  lâ€™existence. On sait jusquâ€™oÃ¹ on est responsable pour soi-mÃªme et oÃ¹ commence la responsabilitÃ© des autres.', 'Jâ€™ai le droit de...Je me pardonne... Je suis dÃ©livrÃ©', 0),
(25, 'Red Chestnut', '1', 0, 0, 'Peurs', 'no', 'Soucis et craintes excessifs pour la sÃ©curitÃ© dâ€™autres personnes; lien affectif trop fort, on sâ€™investit trop dans le monde Ã©motionnel de lâ€™autre. On trouve la juste proportion entre la sollicitude pour quelquâ€™un et le respect de son indÃ©pendance. On enregistre les prÃ©occupations des autres, mais sans les vivre Ã  leur place.', 'Je me centre sur moi-mÃªme, moi et lâ€™autre sommes deux individualitÃ©s distinctes', 0),
(26, 'Rock Rose', '1', 0, 0, 'Peurs', 'no', 'Peur panique, terreur aiguÃ«. Le systÃ¨me nerveux sâ€™emballe. Le plexus solaire est douloureux, le cÅ“ur bat la chamade.\r\nOn connaÃ®t sa capacitÃ© nerveuse et on maÃ®trise les situations problÃ©matiques, on se soumet sciemment Ã  son Guide intÃ©rieur. On intervient pour le salut dâ€™autrui, on est en mesure de se dÃ©passer et de mobiliser une Ã©nergie presque surhumaine.', 'Je sais que tout ira bien, je mâ€™en sortirai', 0),
(27, 'Rock Water', '7', 0, 0, 'Soucis excessif du bien-Ãªtre d''autrui', 'no', 'Conceptions sÃ©vÃ¨res et rigides; rÃ©pression des besoins vitaux; sÃ©vÃ©ritÃ© excessive envers soi-mÃªme. Perfectionniste. IdÃ©aux exagÃ©rÃ©s. SpiritualitÃ© mal comprise, on croit que les plaisirs terrestres entravent le dÃ©veloppement spirituel (ascÃ¨tes, fakirs), on ne parvient pas Ã  entrer en mÃ©ditation parce que la volontÃ© y est prÃ©pondÃ©rante. \r\nOn accepte de suivre ses impulsions ludiques. On respecte ses besoins physiques et Ã©motionnels. On se soumet Ã  son guide intÃ©rieur.', 'Je mâ€™autorise Ã ...Je suis flexible. Je suis spontanÃ©', 0),
(28, 'Scleranthus', '2', 0, 0, 'Incertitudes et dÃ©couragements', 'no', 'IrrÃ©solu; versatile; dÃ©sÃ©quilibre intÃ©rieur, sujet Ã  des brusques sautes dâ€™humeur et de revirements dâ€™opinion. BallottÃ© entre deux possibilitÃ©s qui offrent chacune un avantage. On donne lâ€™impression dâ€™Ãªtre peu fiable.\r\nConcentration et esprit de dÃ©cision. En se centrant sur soi-mÃªme, on trouve son propre rythme et son Ã©quilibre intÃ©rieur. On prend instantanÃ©ment la bonne dÃ©cision.', 'Je suis ferme. Je sais ce que je veux. Je me dÃ©cide', 0),
(29, 'Star of BethlÃ©em', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'Les suites dâ€™un choc physique ou spirituel, que celui-ci soit rÃ©cent ou ancien. Star of BethlÃ©em pour Â«Â conforter lâ€™Ã¢me et apaiser la douleurÂ Â». On est choquÃ© et triste en raison dâ€™un Ã©vÃ©nement douloureux. On est complÃ¨tement  dÃ©stabilisÃ© par une mauvaise nouvelle. \r\nBonne maÃ®trise du monde Ã©motionnel; capacitÃ© Ã  utiliser sciemment les Ã©motions pour son dÃ©veloppement personnel.', 'Je ressens de tout mon Ãªtre. Je respire. Je vis', 0),
(30, 'Sweet Chestnut', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'DÃ©sespoir absolu. On pense Ãªtre parvenu  aux limites de lâ€™endurance humaine. On nâ€™est plus en mesure de voir la lumiÃ¨re au bout du tunnel. Totalement perdu, vide absolu, isolement total. \r\nOn peut comprendre et utiliser une crise comme une chance de transformation. On peut traverser des situations extrÃªmes sans dommage pour lâ€™Ã¢me. On sait quâ€™il y a un moment pour agir et un moment pour laisser faire.', 'Je me relÃ¨ve. Jâ€™accepte. Je laisse faire', 0),
(31, 'Vervain', '7', 0, 0, 'Soucis excessif du bien-Ãªtre d''autrui', 'no', 'Surmenage physique par excÃ¨s de zÃ¨le pour une bonne cause; excitÃ©, voire fanatique. On est exaltÃ© par ses idÃ©es et on voudrait que lâ€™entourage suive. On ne supporte pas les injustices. Pour les convertir, on dÃ©verse trop dâ€™Ã©nergie sur les autres et on les lasse. \r\nOn trouve la juste mesure dans toutes ses activitÃ©s. Attitude tolÃ©rante et dÃ©contractÃ©e. On laisse les autres suivre leurs propres visions du bonheur.', 'Je lÃ¢che prise. Jâ€™accorde un espace aux autres. Jâ€™admets la juste mesure', 0),
(32, 'Vine', '7', 0, 0, 'Soucis excessif du bien-Ãªtre d''autrui', 'no', 'Ambition dominatrice; autoritarisme; tyrannie. On doit avoir raison Ã  tout prix; incapacitÃ© Ã  admettre une dÃ©faite. DifficultÃ©s Ã  obÃ©ir. On passe sans Ã©gards sur les opinions des autres. IntolÃ©rant, on nâ€™accepte que sa propre opinion.  MentalitÃ© de Â«Â Petit chefÂ Â».\r\nOn est rÃ©ceptif aux demandes des autres; en dÃ©cidant, on prend leurs besoins en compte. Le chef sage et comprÃ©hensif, disposant dâ€™une autoritÃ© naturelle.', 'Je tiens compte de la sensibilitÃ© des autres. Je respecte lâ€™autre. Jâ€™honore et  jâ€™aide lâ€™autre', 0),
(33, 'Walnut', '5', 0, 0, 'HypersensibilitÃ© aux influences et idÃ©es d''autrui', 'no', 'Doute, influenÃ§abilitÃ© et irrÃ©solution, surtout en dÃ©but dâ€™une nouvelle phase de vie. Grande modification existentielle: mariage, accouchement, changement de mÃ©tier, dÃ©mÃ©nagement, divorce, retraite, etc. Grandes modifications physiologiques: pubertÃ©, grossesse, mÃ©nopause, maladie au stade terminal.\r\nLe pionnier qui reste fidÃ¨le Ã  lui-mÃªme. On ose se lancer dans lâ€™inconnu. On fait le premier pas. On est impermÃ©able aux influences extÃ©rieures et ouvert Ã  lâ€™intuition. On a du caractÃ¨re. On poursuit son objectif sans se laisser influencer.', 'Je suis sÃ»r de moi-mÃªme. Je reste fidÃ¨le Ã  moi-mÃªme. Je poursuis mon propre chemin', 0),
(34, 'Water Violet', '4', 0, 0, 'Solitudes', 'no', 'Violet RÃ©serve intÃ©rieure; retenue orgueilleuse; sentiment de supÃ©rioritÃ© dans lâ€™isolement.\r\nOn apprÃ©cie la solitude, mais on sait aborder quelquâ€™un quand la situation lâ€™exige. On garde une distance respectueuse de lâ€™autre, mais on se sent en communication avec lui.', 'Je fais partie des autres. Je participe dÃ©libÃ©rÃ©ment.Je me laisse approcher', 0),
(35, 'White Chestnut', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'Certaines  pensÃ©es tournent inlassablement dans la tÃªte, on ne peut sâ€™en dÃ©barrasser. Monologues et dialogues intÃ©rieurs. Suractivation du mental et manque de concentration dans le quotidien. Insomnies.\r\nLe calme intÃ©rieur fait Ã©merger de lui-mÃªme les idÃ©es et le solutions aux problÃ¨mes.', 'Je ressens le calme. Mes pensÃ©es sont claires. Je dirige mes pensÃ©es', 0),
(36, 'Wild Oat', '2', 0, 0, 'Incertitudes et dÃ©couragements', 'no', 'ImprÃ©cision dans ses buts, insatisfaction parce quâ€™on ne voit pas sa tÃ¢che assignÃ©e par la vie. On disperse ses forces dans trop de direction Ã  la fois. Insatisfaction, frustration, ennui.\r\nOn entend sa vocation et on la suit. On est conscient de sa particularitÃ©.', 'Je reconnais le sens. Je poursuis mon but. Je me sens en plÃ©nitude', 0),
(37, 'Wild Rose', '3', 0, 0, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 'no', 'DÃ©sintÃ©rÃªt total, apathie, rÃ©signation, capitulation intÃ©rieure. Attitude fataliste. Perte totale de la joie de vivre et de motivation intÃ©rieure. \r\nOn dit Â«Â ouiÂ Â» Ã  la vie. On prend des initiatives. On trouve lâ€™existence intÃ©ressante.', 'Je veux vivre. Je veux trouver de lâ€™Ã©nergie vitale. Je saisis ma chance de vivre', 0),
(38, 'Willow', '6', 0, 0, 'Abattements et dÃ©sespoir', 'no', 'Rancune, aigreur intÃ©rieures. Â«Â Victime de son destinÂ Â». On se trouve rejetÃ©, dÃ©laissÃ©. Attitude gÃ©nÃ©rale dâ€™aigreur. On boude, on est susceptible, et on essaie de gÃ¢cher la bonne humeur ou lâ€™optimisme des autres. \r\nOn gÃ¨re activement sa propre vie. PensÃ©e constructive qui permet de guider le cours des Ã©vÃ©nements. On accepte sa responsabilitÃ©.', 'Jâ€™ai la force. Jâ€™ai de lâ€™Ã©nergie. Je prends mes responsabilitÃ©s', 0);

-- --------------------------------------------------------

--
-- Structure de la table `groupdescription`
--

CREATE TABLE IF NOT EXISTS `groupdescription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupeDesc` text NOT NULL,
  `groupNumber` int(255) NOT NULL,
  `groupePoints` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `groupdescription`
--

INSERT INTO `groupdescription` (`id`, `groupeDesc`, `groupNumber`, `groupePoints`) VALUES
(1, 'Peurs', 1, 0),
(2, 'Incertitudes et dÃ©couragements', 2, 0),
(3, 'Manque dâ€™intÃ©rÃªt pour la rÃ©alitÃ©', 3, 0),
(4, 'Solitudes', 4, 0),
(5, 'HypersensibilitÃ© aux influences et idÃ©es d''autrui', 5, 0),
(6, 'Abattements et dÃ©sespoir', 6, 0),
(7, 'Soucis excessif du bien-Ãªtre d''autrui', 7, 0);

-- --------------------------------------------------------

--
-- Structure de la table `mails`
--

CREATE TABLE IF NOT EXISTS `mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `senderMail` text NOT NULL,
  `receiverMail` text NOT NULL,
  `mailTitle` text NOT NULL,
  `mailContent` text NOT NULL,
  `mailStatus` text NOT NULL,
  `mailTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `mails`
--

INSERT INTO `mails` (`id`, `senderMail`, `receiverMail`, `mailTitle`, `mailContent`, `mailStatus`, `mailTime`) VALUES
(6, 'YWJyYXJqb3kxMUBnbWFpbC5jb20=', 'YW50b3IuZmVyZG91czk4QGdtYWlsLmNvbQ==', 'dGVzdCBwb3VyIG1haWwgZW52b3nDqXM=', 'Jmx0O3AmZ3Q7dGVzdCBwb3VyIHVuIG1haWwgZW52b3kmYW1wO2VhY3V0ZTsgJmFtcDthZ3JhdmU7IHVuIGF1dHJlIHV0aWxpc2F0ZXVyIGRpZmYmYW1wO2VhY3V0ZTtyZW50Jmx0Oy9wJmd0Ow==', 'unread', '2022-04-04 11:03:22'),
(8, 'YWJyYXJqb3kxMUBnbWFpbC5jb20=', 'YWJyYXJqb3kxMUBnbWFpbC5jb20=', 'bWFpbCBkdSAwNi8wNC8yMDIy', 'Jmx0O3AmZ3Q7dW4gbWFpbCBwb3VyIGxlIDA2LzA0LzIwMjImbHQ7L3AmZ3Q7', 'unread', '2022-04-06 09:42:32'),
(9, 'YWJyYXJqb3kxMUBnbWFpbC5jb20=', 'YW5pdGFraGFuMUBob3RtYWlsLmZy', 'TWFpbCBwb3VyIHRlc3Rlcg==', 'Jmx0O3AmZ3Q7Yydlc3QgdW4gbWFpbCBwb3VyIHRlc3RlciBsZSBib24gZm9uY3Rpb25uZW1lbnQmbHQ7L3AmZ3Q7', 'unread', '2022-04-08 13:49:03');

-- --------------------------------------------------------

--
-- Structure de la table `patientlist`
--

CREATE TABLE IF NOT EXISTS `patientlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientSexe` text NOT NULL,
  `clientFirstName` text NOT NULL,
  `clientLastName` text NOT NULL,
  `clientDateOfBirth` date NOT NULL,
  `clientEmail` text NOT NULL,
  `clientPhoneNumber` text NOT NULL,
  `clientRoadNumber` text NOT NULL,
  `clientRoadName` text NOT NULL,
  `clientAddressAlternate` text NOT NULL,
  `clientPostalCode` text NOT NULL,
  `clientCity` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `patientlist`
--

INSERT INTO `patientlist` (`id`, `clientSexe`, `clientFirstName`, `clientLastName`, `clientDateOfBirth`, `clientEmail`, `clientPhoneNumber`, `clientRoadNumber`, `clientRoadName`, `clientAddressAlternate`, `clientPostalCode`, `clientCity`) VALUES
(3, 'aG9tbWU=', 'RmVyZG91cw==', 'QW50b3I=', '1998-01-04', 'YWJyYXJqb3kxMUBnbWFpbC5jb20=', 'MDc2MTg0NzExOQ==', 'MjE=', 'Ym91bGV2YXJkIGRldmF1eA==', '', 'NzgzMDA=', 'ICAgcG9pc3N5'),
(4, 'ZmVtbWU=', 'RFVCT0lT', 'TWVsaXNzYQ==', '1997-11-14', 'bWVsaXNzYS5kdWJvaXNjQGdtYWlsLmNvbQ==', 'MDYxNjUzMzI4NQ==', 'NDU=', 'cnVlIEFsZXhhbmRyYSBGb3Vybnk=', 'NSBSw6lzaWRlbmNlIGR1IEJ1aXNzb24=', 'OTQ1MDA=', 'Q0hBTVBJR05ZIFNVUiBNQVJORQ=='),
(5, 'ZmVtbWU=', 'RFVCT0lT', 'TWVsaXNzYQ==', '1997-11-14', 'bWVsaXNzYS5kdWJvaXNjQGdtYWlsLmNvbQ==', 'MDYxNjUzMzI4NQ==', 'NDU=', 'cnVlIEFsZXhhbmRyYSBGb3Vybnk=', 'NSBSw6lzaWRlbmNlIGR1IEJ1aXNzb24=', 'OTQ1MDA=', 'Q0hBTVBJR05ZIFNVUiBNQVJORQ==');

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire1`
--

CREATE TABLE IF NOT EXISTS `questionnaire1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text CHARACTER SET utf32 NOT NULL,
  `reponse` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Contenu de la table `questionnaire1`
--

INSERT INTO `questionnaire1` (`id`, `question`, `reponse`) VALUES
(1, 'Je me sens actuellement comme un acteur sur scÃ¨ne qui doit rire, mÃªme quand il nâ€™en a pas envie.', 'Agrimony'),
(2, 'Je me sens actuellement menacÃ©, saisi de peurs sans formes.', 'Aspen'),
(3, 'Je me sens actuellement agacÃ©, hypercritique, intolÃ©rant ou, au contraire sans le moindre sens critique.', 'Beech'),
(4, 'Je me sens actuellement trop faible de volontÃ©, trop soumisÂ  ; je ne sais pas dire non.', 'Centaury'),
(5, 'Je me sens actuellement insÃ©curisÃ©. Je doute de ma capacitÃ© de jugement et jâ€™agis en fonction de lâ€™opinion des autres.', 'Cerato'),
(6, 'Je me sens actuellement comme assis sur une poudriÃ¨reÂ  ; je ne peux presque plus me maÃ®triser.', 'Cherry Plum'),
(7, 'Je me sens actuellement Ã©tonnÃ©, parce que je recommence toujours les mÃªmes erreurs.', 'Chestnut Bud'),
(8, 'Je me sens actuellement peu reconnu, peu aimÃ©, vexÃ©, dÃ©Ã§u, parce que je mâ€™Ã©tais attendu Ã  plus de gratitude.', 'Chicory'),
(9, 'Je me sens actuellement peu concernÃ© parce que mes pensÃ©es sont ailleurs ', 'ClÃ©matis'),
(10, 'Je me sens actuellement irritÃ© par le dÃ©sordre, souillÃ©, Sali, dÃ©goutÃ©.', 'Crab Apple'),
(11, 'Je me sens actuellement dÃ©passÃ© par mes responsabilitÃ©s. Je ne peux plus y faire face.', 'Elm'),
(12, 'Je me sens actuellement dÃ©couragÃ©, sceptique, pessimiste.', 'Gentian'),
(13, 'Je me sens actuellement sans espoir, rÃ©signÃ©.', 'Gorse'),
(14, 'Je me sens actuellement en besoin dâ€™Ã©coute. Jâ€™ai besoin quâ€™on sâ€™occupe de moi.', 'Heather'),
(15, 'Je me sens actuellement mÃ©fiant, blessÃ©, en colÃ¨re, hostile, jaloux, haineux.', 'Holly'),
(16, 'Je me sens actuellement nostalgique. Je ne parviens pas Ã  tirer un trait sur le passÃ© (une relation ou une situation).', 'Honeysuckle'),
(17, 'Je me sens actuellement sans le moindre tonus, incapable dâ€™action. Je manque de force et de dynamisme pour accomplir mes tÃ¢ches.', 'Hornbeam'),
(18, 'Je me sens actuellement impatient. Tout avance trop lentement.', 'Impatiens'),
(19, 'Je me sens actuellement complexÃ©, infÃ©rieur, moins capable que les autres.', 'Larch'),
(20, 'Je me sens actuellement craintif. Jâ€™ai peur de.....', 'Mimulus'),
(21, 'Je me sens actuellement triste, dÃ©pressif, mÃ©lancolique sans savoir pourquoi.', 'Mustard'),
(22, 'Je me sens actuellement comme un combattant Ã©puisÃ©, mais sur qui repose toute la responsabilitÃ©.', 'Oak'),
(23, 'Je me sens actuellement sans force, Ã©puisÃ©, vidÃ©.', 'Olive'),
(24, 'Je me sens actuellement coupable. Je me fais des reproches.', 'Pine'),
(25, 'Je me sens actuellement tellement impliquÃ© dans la situation de quelquâ€™un dâ€™autre que je suis incapable de ressentir mes propres Ã©motions et craintes.', 'Red Chestnut'),
(26, 'Je me sens actuellement en pleine panique. Jâ€™en perds les nerfs, et la tÃªte.', 'Rock Rose'),
(27, 'Je me sens actuellement comme un athlÃ¨te de haut niveau, obligÃ© de sâ€™entraÃ®ner coÃ»te que coÃ»te.', 'Rock Water'),
(28, 'Je me sens actuellement dÃ©chirÃ© entre deux choix possibles, jâ€™en ai perdu mon Ã©quilibre.', 'Scléranthus'),
(29, 'Je me sens actuellement complÃ¨tement sous le choc, je nâ€™ai pas rÃ©sorbÃ© ce traumatisme.', 'Star of BethlÃ©em'),
(30, 'Je me sens actuellement Â«Â  au bout du rouleauÂ  Â», totalement dÃ©sespÃ©rÃ©, je ne sais plus comment continuer.', 'Sweet Chestnut'),
(31, 'Je me sens actuellement motivÃ© Ã  fond.', 'Vervain'),
(32, 'Je me sens actuellement abandonnÃ©, maltraitÃ© par le sort.', 'Vine'),
(33, 'Je me sens actuellement peu fidÃ¨le Ã  mes dÃ©cisions. Je crains de ne pas Ãªtre assez solide pour tenir bon dans mes choix. Je voudrais enfin pouvoir passer Ã  lâ€™action.', 'Walnut'),
(34, 'Je me sens actuellement distant, je voudrais me retirer, Ãªtre tranquille.', 'Water Violet'),
(35, 'Je me sens actuellement sous lâ€™emprise de pensÃ©es et de dialogues intÃ©rieurs obsessionnels que je ne parviens pas Ã  arrÃªter.', 'White Chestnut'),
(36, 'Je me sens actuellement indÃ©cis, Â«Â  dans le brouillardÂ  Â», sans perception claire de ce que je veux rÃ©ellement.', 'Wild Oat'),
(37, 'Je me sens actuellement totalement dÃ©sintÃ©ressÃ©. Je me suis fait Ã  mon sort.', 'Wild Rose'),
(38, 'Je me sens actuellement abandonnÃ©, maltraitÃ© par le sort.', 'Willow');

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire2`
--

CREATE TABLE IF NOT EXISTS `questionnaire2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `reponse` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Contenu de la table `questionnaire2`
--

INSERT INTO `questionnaire2` (`id`, `question`, `reponse`) VALUES
(1, 'Ce qui me bloque, câ€™est mon besoin dâ€™environnement harmonieux. Je veux absolument Ã©viter les disputes et les discussions dÃ©sagrÃ©ables.', 'Agrimony'),
(2, 'Ce qui me bloque, ce sont mes pressentiments envahissants. Quand jâ€™y pense, jâ€™ai une sensation de catastrophe imminente.', 'Aspen'),
(3, 'Ce qui me bloque, câ€™est ma tendance extrÃªme Ã  la critique ou Ã  lâ€™autocritique. Presque tout me dÃ©plaÃ®t, mais je ne parviens pas Ã  modifier mon attitude.', 'Beech'),
(4, 'Ce qui me bloque, câ€™est mon manque de volontÃ©. Je ne peux jamais dire non.', 'Centaury'),
(5, 'Ce qui me bloque, câ€™est mon manque dâ€™assurance personnelle. Je ne cesse de demander leur avis aux autres, pour Ãªtre sÃ»r de ne pas me tromper.', 'Cerato'),
(6, 'Ce qui me bloque, câ€™est la peur dâ€™Ãªtre confrontÃ© Ã  la violence de mes sentiments. Jâ€™ai peur de perdre mon contrÃ´le si je me relÃ¢che.', 'Cherry Plum'),
(7, 'Ce qui me bloque, câ€™est mon inattentionÂ  : je ne cesse de recommencer les mÃªmes erreurs.', 'Chestnut Bud'),
(8, 'Ce qui me bloque, câ€™est de mâ€™attendre toujours Ã  un retour dâ€™affection de la part des autres. Je mâ€™immisce dans leurs affaires et attends un retour de gratitude.', 'Chicory'),
(9, 'Ce qui me bloque, câ€™est mon manque dâ€™intÃ©rÃªt pour la situation telle quâ€™elle est, parce quâ€™en pensÃ©es je suis tout Ã  fait ailleurs.', 'ClÃ©matis'),
(10, 'Ce qui me bloque, câ€™est mon perfectionnisme, mon sens de la propretÃ© poussÃ© Ã  lâ€™extrÃªme. MÃªme les dÃ©tails doivent Ãªtre parfaits, ou je mâ€™Ã©nerve.', 'Crab Apple'),
(11, 'Ce qui me bloque, câ€™est mon sentiment de ne pouvoir faire face Ã  mes responsabilitÃ©s. Jâ€™ai lâ€™impression dâ€™avoir une montagne devant moi.', 'Elm'),
(12, 'Ce qui me bloque, câ€™est mon scepticisme fondamental. En fait, je ne mâ€™attends jamais Ã  ce que quelque chose rÃ©ussisse.', 'Gentian'),
(13, 'Ce qui me bloque, câ€™est mon sentiment de dÃ©sespoir. Je crois que cela ne servirait plus Ã  rien.', 'Gorse'),
(14, 'Ce qui me bloque, câ€™est dâ€™Ãªtre trÃ¨s prÃ©occupÃ© par moi-mÃªme. Je nâ€™ai tout simplement pas de sensibilitÃ© pour les besoins des autres.', 'Heather'),
(15, 'Ce qui me bloque, câ€™est ma mÃ©fiance, ma jalousie latente. Je suis vite agressif.', 'Holly'),
(16, 'Ce qui me bloque, câ€™est mon rapport au passÃ©Â  : je ne peux pas oublier ce quâ€™il y avait avant.', 'Honeysuckle'),
(17, 'Ce qui me bloque, câ€™est mon manque de dynamisme. Quand je pense Ã  ce que je dois faire, Ã§a mâ€™Ã©puise dâ€™avance.', 'Hornbeam'),
(18, 'Ce qui me bloque, câ€™est mon impatience. Je ne peux tout simplement pas attendre.', 'Impatiens'),
(19, 'Ce qui me bloque, câ€™est mon manque de confiance en moi. Je suis persuadÃ© que je nâ€™y arriverai pas.', 'Larch'),
(20, 'Ce qui me bloque, câ€™est mon inquiÃ©tude. Jâ€™ai peur que tout soit trÃ¨s laborieux et engendre beaucoup de changement.', 'Mimulus'),
(21, 'Ce qui me bloque, câ€™est ma nature dÃ©pressiveÂ  ; par moment elle mâ€™empÃªche dâ€™Ãªtre actif.', 'Mustard'),
(22, 'Ce qui me bloque, câ€™est mon sens des responsabilitÃ©s exagÃ©rÃ©. Je me trouve toujours obligÃ© dâ€™aller jusquâ€™au bout.', 'Oak'),
(23, 'Ce qui me bloque, câ€™est mon manque dâ€™Ã©nergie. Je suis totalement Ã©puisÃ©, incapable du moindre effort.', 'Olive'),
(24, 'Ce qui me bloque, câ€™est ma mauvaise conscience habituelle. Je sais que je vais encore culpabiliser.', 'Pine'),
(25, 'Ce qui me bloque, câ€™est de me mettre trop Ã  la place des autres. Je ressens trop leurs propres Ã©motions et je ne parviens pas Ã  me dÃ©limiter par rapport Ã  eux.', 'Red Chestnut'),
(26, 'Ce qui me bloque, câ€™est ma mauvaise tendance Ã  lâ€™affolement. Dans ma tÃªte, câ€™est la panique, rien que dâ€™y penser.', 'Rock Rose'),
(27, 'Ce qui me bloque, câ€™est la discipline de fer que je mâ€™impose. Jâ€™exige trop de moi-mÃªme, sans mâ€™accorder le moindre petit plaisir.', 'Rock Water'),
(28, 'Ce qui me bloque, câ€™est mon indÃ©cision fondamentale. Parfois je trouve une solution bonne et parfois une autre.', 'Scleranthus'),
(29, 'Ce qui me bloque, câ€™est ma vulnÃ©rabilitÃ© Ã©motionnelle. Je nâ€™ai toujours pas rÃ©sorbÃ© le choc de certaines situations antÃ©rieures.', 'Star of BethlÃ©em'),
(30, 'Ce qui me bloque, câ€™est ma tendance Ã  laisser Ã©voluer une situation jusquâ€™au bout et de ne plus voir dâ€™issue Ã  la fin.', 'Sweet Chestnut'),
(31, 'Ce qui me bloque, câ€™est mon excÃ¨s dâ€™enthousiasme. Je sais que je vais de nouveau exagÃ©rer et vouloir tout faire trop bien, mÃªme au prix dâ€™Ã©nerver les autres ou alors Ce qui me pose un problÃ¨me, câ€™est mon extrÃªme sens de justiceÂ  ; je ne peux tout simplement pas laisser faire sans intervenir. ', 'Vervain'),
(32, 'Ce qui me bloque, câ€™est ma volontÃ© dâ€™Ãªtre toujours le premier. Il faut absolument que jâ€™arrive Ã  mes fins. ', 'Vine'),
(33, 'Ce qui me bloque, câ€™est mon manque de constance dans une dÃ©cision prise. Je me laisse constamment influencer par les autres au lieu de rester fidÃ¨le Ã  moiâ€“mÃªme.', 'Walnut'),
(34, 'Ce qui me bloque, câ€™est ma tendance Ã  mâ€™isoler. Il mâ€™est difficile de participer ou dâ€™aborder constructivement les autres.', 'Water Violet'),
(35, 'Ce qui me bloque, ce sont les idÃ©es qui tournent dans la tÃªte comme dans un manÃ¨ge. Je ne parviens plus Ã  me centrer sur lâ€™essentiel.', 'White Chestnut'),
(36, 'Ce qui me bloque, câ€™est mon incertitude globaleÂ  ; je ne sais pas si je veux rÃ©ellement aller vers ce but.', 'Wild Oat'),
(37, 'Ce qui me bloque, câ€™est mon apathie, mon manque dâ€™intÃ©rÃªt fondamental. Sortir de la situation mâ€™est en rÃ©alitÃ© indiffÃ©rentÂ  ; entre-temps, je mâ€™y suis fait.', 'Wild Rose'),
(38, 'Ce qui me bloque, câ€™est mon Ã©tat dâ€™amertume. Jâ€™ai lâ€™impression dâ€™Ãªtre victime de la situation, sans possibilitÃ© dâ€™action rÃ©elle.', 'Willow');

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire3`
--

CREATE TABLE IF NOT EXISTS `questionnaire3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `reponse` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Contenu de la table `questionnaire3`
--

INSERT INTO `questionnaire3` (`id`, `question`, `reponse`) VALUES
(1, 'La recherche de lâ€™harmonie Ã  tout prix', 'Agrimony'),
(2, 'Les peurs inexplicables', 'Aspen'),
(3, 'Lâ€™intolÃ©rance, la critique', 'Beech'),
(4, 'Le fait de ne pouvoir dire non ', 'Centaury'),
(5, 'La manque dâ€™assurance personnelle', 'Cerato'),
(6, 'La sensation dâ€™Ãªtre assis sur une poudriÃ¨re', 'Cherry plum'),
(7, 'La tendance Ã  refaire les mÃªmes erreurs', 'Chestnut Bud'),
(8, 'Le besoin immodÃ©rÃ© de lâ€™affection des autres', 'Chicory'),
(9, 'Lâ€™absence mentale ', 'ClÃ©matis'),
(10, 'La maniaquerie', 'Crab Apple'),
(11, 'La peur de ne pas Ãªtre Ã  la hauteur', 'Elm'),
(12, 'Lâ€™attitude fondamentale d Ã©chec', 'Gentian'),
(13, 'La rÃ©signation', 'Gorse'),
(14, 'Lâ€™Ã©gocentrisme', 'Heather'),
(15, 'La mÃ©fiance, la jalousie, la colÃ¨re ', 'Holly'),
(16, 'Les liens trop forts avec le passÃ©', 'Honeysuckle'),
(17, 'Le manque dâ€™entrain', 'Hornbeam'),
(18, 'Lâ€™impatience', 'Impatiens'),
(19, 'Le manque de confiance en soi', 'Larch'),
(20, 'La peur', 'Mimulus'),
(21, 'La mÃ©lancolie paralysante', 'Mustard'),
(22, 'Le fait de vouloir tenir Ã  tout prix', 'Oak'),
(23, 'Lâ€™Ã©puisement', 'Olive'),
(24, 'La culpabilitÃ©', 'Pine'),
(25, 'Lâ€™emphase exagÃ©rÃ©e', 'Red Chestnut'),
(26, 'La sensation de panique', 'Rock Rose'),
(27, 'Lâ€™autodiscipline excessive', 'Rock Water'),
(28, 'Lâ€™indÃ©cision ', 'Scleranthus'),
(29, 'La vulnÃ©rabilitÃ© Ã©motionnelle', 'Star of BethlÃ©em'),
(30, 'La sensation dâ€™Ãªtre au fond dâ€™un gouffre', 'Sweet Chestnut'),
(31, 'Lâ€™excÃ¨s de zÃ¨le', 'Vervain'),
(32, 'Le volontarisme Ã©goÃ¯ste', 'Vine'),
(33, 'Le manque de constance', 'Walnut'),
(34, 'La tendance Ã  lâ€™isolement', 'Water Violet'),
(35, 'Le ruminations mentale', 'White chestnut'),
(36, 'Lâ€™incertitude intÃ©rieure gÃ©nÃ©rale', 'Wild Oat'),
(37, 'Lâ€™apathie', 'Wild Rose'),
(38, 'Le ressentiment', 'Willow');

-- --------------------------------------------------------

--
-- Structure de la table `questionnaire4`
--

CREATE TABLE IF NOT EXISTS `questionnaire4` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` text NOT NULL,
  `reponse` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=39 ;

--
-- Contenu de la table `questionnaire4`
--

INSERT INTO `questionnaire4` (`id`, `question`, `reponse`) VALUES
(1, 'Lâ€™aptitude Ã  faire face Ã  un conflit', 'Agrimony'),
(2, 'Etre moins rÃ©ceptif aux ambiances', 'Aspen'),
(3, 'La tolÃ©rence', 'Beech'),
(4, 'Avoir plus de volontÃ©', 'Centaury'),
(5, 'Plus de confiance dans mon intuition', 'Cerato'),
(6, 'La sÃ©rÃ©nitÃ© intÃ©rieure', 'Cherry plum'),
(7, 'Tirer mieux la leÃ§on des erreurs', 'Chestnut Bud'),
(8, 'Me contenter de mes propres sentiments', 'Chicory'),
(9, 'Le sens des rÃ©alitÃ©s', 'ClÃ©matis'),
(10, 'Un rapport Ã  la propretÃ© normal', 'Crab Apple'),
(11, 'Plus dâ€™assurance', 'Elm'),
(12, 'Plus d optimisme', 'Gentian'),
(13, 'Un nouvel espoir', 'Gorse'),
(14, 'Accaparer moins les autres', 'Heather'),
(15, 'Le sentiment dâ€™amour', 'Holly'),
(16, 'Vivre au moment prÃ©sent', 'Honeysuckle'),
(17, 'La motivation', 'Hornbeam'),
(18, 'La patience', 'Impatiens'),
(19, 'La confiance en soi ', 'Larch'),
(20, 'Le courage', 'Mimulus'),
(21, 'La lumiÃ¨re, la lÃ©gÃ¨retÃ©', 'Mustard'),
(22, 'Prendre mes responsabilitÃ©s avec plus de recul', 'Oak'),
(23, 'Le repos, reconstituer mes rÃ©serves dâ€™Ã©nergie', 'Olive'),
(24, 'Mâ€™accepter sans culpabiliser', 'Pine'),
(25, 'Etre plus autonome dans mes sentiments', 'Red Chestnut'),
(26, 'Des nerfs plus solides', 'Rock Rose'),
(27, 'Etre plus flexible', 'Rock Water'),
(28, 'Lâ€™Ã©quilibre intÃ©rieur, les dÃ©cisions nettes', 'Scleranthus'),
(29, 'RÃ©sorber les chocs', 'Star of BethlÃ©em'),
(30, 'La lumiÃ¨re Ã  la sortie du gouffre', 'Sweet Chestnut'),
(31, 'Des engagements plus mesurÃ©s', 'Vervain'),
(32, 'Tenir compte des autres', 'Vine'),
(33, 'La constance, la persÃ©vÃ©rance', 'Walnut'),
(34, 'Une meilleure communication', 'Water Violet'),
(35, 'Le calme dans mes pensÃ©es', 'White chestnut'),
(36, 'Un but prÃ©cis', 'Wild Oat'),
(37, 'Une nouvelle motivation pour vivre', 'Wild Rose'),
(38, 'Lâ€™acceptation du destin', 'Willow');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `username` varchar(30) NOT NULL,
  `code` text,
  `status` text,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `sexe` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `dob`, `username`, `code`, `status`, `firstname`, `lastname`, `sexe`) VALUES
(13, 'aGVsbG8xMjNAZ21haWwuY29t', 'aGVsbG8xMjM=', '1989-11-30', 'aGVsbG8=', NULL, 'utilisateur', '', '', 'm'),
(14, 'YWJyYXJqb3kxMUBnbWFpbC5jb20=', 'Ym9sbGFuZDIwMTM=', '1998-01-04', 'YW50b3JmZXJkb3Vz', '8395', 'utilisateur', 'QW50b3I=', 'RmVyZG91cw==', 'm'),
(15, 'dGVzdEBnbWFpbC5jb20=', 'YWRtaW4=', '1998-01-04', 'YWRtaW4=', NULL, 'administrateur', 'QW50b3I=', 'RmVyZG91cw==', 'm'),
(21, 'YW5pdGFraGFuMUBob3RtYWlsLmZy', 'Z2R5dnZo', '1998-12-29', 'YW5pdGFraGFu', NULL, 'utilisateur', 'QW5pdGE=', 'S2hhbg==', 'f');
--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `filedetails`
--

CREATE TABLE IF NOT EXISTS `filedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filepath` text NOT NULL,
  `filename` text NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `filedetails`
--

INSERT INTO `filedetails` (`id`, `filepath`, `filename`, `description`) VALUES
(1, 'files/test.txt', 'test.txt', ''),
(2, 'files/plaquette CVPN.png', 'plaquette CVPN.png', '');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_on` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `images`
--

INSERT INTO `images` (`id`, `file_name`, `uploaded_on`, `status`) VALUES
(1, 'plaquette CVPN.png', '2022-04-08 11:01:28', '1'),
(2, 'test.txt', '2022-04-08 11:05:41', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
